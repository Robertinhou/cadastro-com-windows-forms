using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System.Data;
using System.Security.Cryptography.X509Certificates;


namespace sistema_escola
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }




        private void btnListar_Click(object sender, EventArgs e)
        {



            string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
            MySqlConnection conexao = new MySqlConnection(conexaoBanco);

            conexao.Open();

            string sql = "SELECT * FROM alunos";

            MySqlDataAdapter dataAdapter = new MySqlDataAdapter(sql, conexao);

            DataTable dataTable = new DataTable();

            dataAdapter.Fill(dataTable);

            dgvAlunos.DataSource = dataTable;

            dgvAlunos.AutoResizeColumns();

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

            try
            {
                string nome = txtNome.Text;
                string telefone = txtTelefone.Text;
                string curso = txtCurso.Text;
                string nasc = txtNascimento.Text;

                DateTime dataMySqlFormat = Convert.ToDateTime(nasc);
                string dataNascimentoFormatada = dataMySqlFormat.ToString("yyyy-MM-dd");

                string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
                MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                conexao.Open();

                string insert = "INSERT INTO alunos (nome, telefone, curso, nascimento) VALUES (@nome, @telefone, @curso, @nasc)";

                MySqlCommand insertAluno = new MySqlCommand(insert, conexao);

                insertAluno.Parameters.AddWithValue("@nome", nome);
                insertAluno.Parameters.AddWithValue("@telefone", telefone);
                insertAluno.Parameters.AddWithValue("@curso", curso);
                insertAluno.Parameters.AddWithValue("@nasc", dataNascimentoFormatada);


                int contLines = Convert.ToInt32(insertAluno.ExecuteNonQuery());

                if (contLines > 0)
                {

                    MessageBox.Show("Usu�rio cadastrado!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {

                    MessageBox.Show("N�o foi poss�vel cadastrar!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

            txtCurso.Text = "";
            txtTelefone.Text = "";
            txtNome.Text = "";
            txtNascimento.Text = "";


        }


        public int buscaId()
        {

            int idAlunoSelected = Convert.ToInt32(dgvAlunos.CurrentRow.Cells[0].Value.ToString());
            return idAlunoSelected;

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = txtNome.Text;
                string telefone = txtTelefone.Text;
                string curso = txtCurso.Text;
                string nasc = txtNascimento.Text;

                DateTime dataMySqlFormat = Convert.ToDateTime(nasc);
                string dataNascimentoFormatada = dataMySqlFormat.ToString("yyyy-MM-dd");

                string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
                MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                conexao.Open();



                txtNascimento.Enabled = true;

              

                txtNome.Text = "";
                txtNascimento.Text = "";
                txtCurso.Text = "";
                txtTelefone.Text = "";

                int idAluno = buscaId();



                string update = "UPDATE alunos SET nome = @nome, telefone = @telefone, curso = @curso, nascimento = @nasc WHERE id = @id";
                MySqlCommand updateAluno = new MySqlCommand(update, conexao);

                updateAluno.Parameters.AddWithValue("@nome", nome);
                updateAluno.Parameters.AddWithValue("@telefone", telefone);
                updateAluno.Parameters.AddWithValue("@curso", curso);
                updateAluno.Parameters.AddWithValue("@nasc", dataNascimentoFormatada);
                updateAluno.Parameters.AddWithValue("@id", idAluno);

                int contLines = updateAluno.ExecuteNonQuery();

                if (contLines > 0)
                {
                    MessageBox.Show("Dados alterados!", "Atualiza��o de dados", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("N�o foi poss�vel editar!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }



                conexao.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvAlunos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {

                DialogResult resultado = MessageBox.Show("Deseja apagar esse registro?", "Atualiza��o de dados", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (resultado == DialogResult.Yes)
                {

                    string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
                    MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                    conexao.Open();


                    string delete = "DELETE FROM alunos WHERE nome = @nome";
                    MySqlCommand selectIdAluno = new MySqlCommand(delete, conexao);
                    selectIdAluno.Parameters.AddWithValue("@nome", dgvAlunos.CurrentRow.Cells[1].Value.ToString());

                    int result = Convert.ToInt32(selectIdAluno.ExecuteNonQuery());

                    if (result > 0)
                    {

                        MessageBox.Show("Dados deletados!", "Atualiza��o de dados", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("N�o foi poss�vel deletar!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                    conexao.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public void dgvAlunos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {



            txtNome.Text = dgvAlunos.CurrentRow.Cells[1].Value.ToString();
            txtTelefone.Text = dgvAlunos.CurrentRow.Cells[2].Value.ToString();
            txtCurso.Text = dgvAlunos.CurrentRow.Cells[3].Value.ToString();

            txtNascimento.Text = dgvAlunos.CurrentRow.Cells[4].Value.ToString();

       
          






        }



        private void btnCancelar_Click(object sender, EventArgs e)
        {

            txtNascimento.Enabled = true;

            

            txtNome.Text = "";
            txtNascimento.Text = "";
            txtCurso.Text = "";
            txtTelefone.Text = "";

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
            MySqlConnection conexao = new MySqlConnection(conexaoBanco);

            conexao.Open();

            string sql = "SELECT * FROM alunos";

            MySqlDataAdapter dataAdapter = new MySqlDataAdapter(sql, conexao);

            DataTable dataTable = new DataTable();

            dataAdapter.Fill(dataTable);

            dgvAlunos.DataSource = dataTable;

            dgvAlunos.AutoResizeColumns();
            dgvAlunos.CurrentCell = null;

        }
    }
}

