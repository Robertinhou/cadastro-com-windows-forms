using MySql.Data.MySqlClient;
using System.Data;

namespace sistema_escola
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }




        private void btnListar_Click(object sender, EventArgs e)
        {



            string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
            MySqlConnection conexao = new MySqlConnection(conexaoBanco);

            conexao.Open();

            string sql = "SELECT * FROM alunos";

            MySqlDataAdapter dataAdapter = new MySqlDataAdapter(sql, conexao);

            DataTable dataTable = new DataTable();

            dataAdapter.Fill(dataTable);

            dgvAlunos.DataSource = dataTable;

            dgvAlunos.AutoResizeColumns();

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

            try
            {
                string nome = txtNome.Text;
                string telefone = txtTelefone.Text;
                string curso = txtCurso.Text;
                string nasc = txtNascimento.Text;

                DateTime dataMySqlFormat = Convert.ToDateTime(nasc);
                string dataNascimentoFormatada = dataMySqlFormat.ToString("yyyy-MM-dd");

                string conexaoBanco = "Server=localHost; Database=escola; Uid=root; pwd=''";
                MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                conexao.Open();

                string insert = "INSERT INTO alunos (nome, telefone, curso, nascimento) VALUES (@nome, @telefone, @curso, @nasc)";

                MySqlCommand insertAluno = new MySqlCommand(insert, conexao);

                insertAluno.Parameters.AddWithValue("@nome", nome);
                insertAluno.Parameters.AddWithValue("@telefone", telefone);
                insertAluno.Parameters.AddWithValue("@curso", curso);
                insertAluno.Parameters.AddWithValue("@nasc", dataNascimentoFormatada);


                int contLines = Convert.ToInt32(insertAluno.ExecuteNonQuery());

                if (contLines > 0)
                {

                    MessageBox.Show("Usu�rio cadastrado!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {

                    MessageBox.Show("N�o foi poss�vel cadastrar!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

            txtCurso.Text = "";
            txtTelefone.Text = "";
            txtNome.Text = "";
            txtNascimento.Text = "";


        }

        private void btnEditar_Click(object sender, EventArgs e)
        {

        }
    }
}
